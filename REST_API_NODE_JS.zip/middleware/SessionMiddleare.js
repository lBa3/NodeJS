'use strict'

/*
by: lbatres
created_at: 17-12-2020
*/





//export
module.exports = app;