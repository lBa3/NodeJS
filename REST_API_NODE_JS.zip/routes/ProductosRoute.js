'use strict'

/*
by: lbatres
created_at: 17-12-2020
*/

var express = require('express');
var ProductoController = require('../controllers/ProductosController');
var router = express.Router();

router.get('/home', ProductoController.home);
router.post('/test', ProductoController.test);
router.post('/login', ProductoController.login);
router.post('/demo', ProductoController.demo);
router.post('/save-producto', ProductoController.saveProduct);
router.get('/get-product/:id', ProductoController.getProduct);
router.get('/get-all-product', ProductoController.getAllProducts);
router.put('/edit-product/:id', ProductoController.updateProduct);
router.delete('/delete-product/:id', ProductoController.deleteProduct);


module.exports = router;