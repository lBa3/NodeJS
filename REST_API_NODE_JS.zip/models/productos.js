'use strict'

/*
by: lbatres
created_at: 17-12-2020
*/

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var ProductosSchema = Schema({
	name: String,
	description: String,
	category: String,
	key: String,
	year: Number,
	coste: String,
	image: String
});

module.exports = mongoose.model('productos2', ProductosSchema);
