'use strict'

/*
by: lbatres
created_at: 17-12-2020
*/

var mongoose = require('mongoose');
var app = require ('./app');
var port = 3700;

mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost:27017/catalgo')
        .then(() => {
        	console.log("conexion BD exitosa!!!!!!!!!!!!!");

        	//make server
        	app.listen(port, () => {
        		console.log('Servidor iniciado correctamente - localhost:3700 -!!!!!!!!!!!');
        	});
        })
        .catch(err => console.log(err));
