'use strict'

/*
by: lbatres
created_at: 17-12-2020
*/

var Producto = require('../models/productos');
var jwt = require('jsonwebtoken');
var url = require('url');
var fs = require('fs');



var controller = {

	
	home: function (req, res){
		return res.status(200).send({
			message: 'home'
		});
	},


	test: function (req, res){

		var token = VerifyToken(req, res);

        jwt.verify(token, 'SecretKey', (err, authData) =>{

        	if(err){
        		res.sendStatus(403);
        	}else{
        		res.json({
        			mensaje: "hola!",
        			authData: authData
        		});
        	}
        });
	},

	demo: function (req, res){

		var params = req.body;
		var name   = params.name;
		var email  = params.email;
		var dataUrl =   getFormattedUrl(req);
		var cadena = 'Name: '+name+' Emnail:'+email+' URL:'+dataUrl;
		

		fs.writeFile('DataPost.txt', cadena, function (err) {
              if (err) return console.log(err);
              console.log('Data Post > DataPost.txt');
        });

		return res.status(200).send({

			name: name,
			email: email,
			dataUrl: dataUrl,
			message: 'demo'
		});
	},

	login: function (req, res){
        var user = {
        	id: 1,
        	nombre: "Lbatres",
        	email: "llbatres@mail.com"
        } 

        jwt.sign({usuario:user},'SecretKey', (err, token) => {
        	res.json({
        		token: token
        	});
        });
	},



	saveProduct: function (req, res){
		var product = new Producto();

		var params = req.body;
		product.name = params.name;
		product.description = params.description;
		product.category = params.category;
		product.key =  params.key;
		product.year = params.year;
		product.coste = params.coste;
		product.image = null;

		product.save((err, productStored) => {
			if (err) return res.status(500).send({message: 'ups! error en el insert a BD!! '});

			if(!productStored) return res.status(404).send({ message: 'ups! error al guardar el producto!! '  });

			return res.status(200).send({ product: productStored });
		});

	},


	getProduct: function (req, res){
		var productId = req.params.id;

		Producto.findById(productId, (err, producto) => {
			if (err) return res.status(500).send({message: 'ups! el produto que buscas no existe!!'});

			if(!producto) return res.status(404).send({ message: 'ups! error al realizar la consulta '  });

			return res.status(200).send({ producto });
		});
	},


	getAllProducts: function (req, res){
		Producto.find({}).sort('-coste').exec((err, productos) => {
			if (err) return res.status(500).send({message: 'ups! error en entregar los datos'});

			if(!productos) return res.status(404).send({ message: 'ups! error no hay productos'  });

			return res.status(200).send({ productos });

		});
	},

	updateProduct: function(req, res){
		var productId = req.params.id;
		var update = req.body;
		Producto.findByIdAndUpdate(productId, update, {new:true}, (err, productUpdated) => {

			if (err) return res.status(500).send({message: 'ups! error al actualizar'});

			if(!productUpdated) return res.status(404).send({ message: 'ups! error no existe'  });

			return res.status(200).send({ producto : productUpdated });

		});
	},

	deleteProduct: function (req, res){
		var productId = req.params.id;
		Producto.findByIdAndRemove(productId, (err, productDelete) => {

			if (err) return res.status(500).send({message: 'ups! error al eliminar el registro'});

			if(!productDelete) return res.status(404).send({ message: 'ups! error al eliminar'  });

			return res.status(200).send({ producto : productDelete });

		});


	}


};



//funcion de token -> return token
//Authorization: Bearer <token>
function VerifyToken(req, res){
     var bearerHeader = req.headers['authorization'];

     if(typeof bearerHeader !== 'undefined'){
     	   var bearerToken = bearerHeader.split(" ")[1];
     	   req.token = bearerToken;
     	   //next();
     	   return req.token;
     }else{
     	res.sendStatus(403);
     }
}


//get Url
function getFormattedUrl(req) {
    return url.format({
        protocol: req.protocol,
        host: req.get('host')
    });
}


module.exports = controller;